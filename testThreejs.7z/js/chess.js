//1-king 2-queen 3-bishop 4-knight 5-rook 6-pawn
var chessScale=0.005;

var arrayBoard=new Array(5,4,3,2,1,3,4,5,
				6,6,6,6,6,6,6,6,
				0,0,0,0,0,0,0,0,
				0,0,0,0,0,0,0,0,
				0,0,0,0,0,0,0,0,
				0,0,0,0,0,0,0,0,
				12,12,12,12,12,12,12,12,
				11,10,9,8,7,9,10,11);

//modelBoard modelKing,modelQueen,modelBishop,modelKnight,modelRook,modelPawn;
var arrayModel=[];
var scene;

var loader=new THREE.OBJLoader();
function loadChessboard(){
	var texture=new THREE.TextureLoader().load("texture/chess.png");
	texture.flipY=false;
	texture.offset.x=0;
	texture.offset.y=-0.28;
	
	loader.load("obj/chessboard.obj",function(obj){
		obj.traverse( function ( child ) {
			if ( child.isMesh ) child.material.map = texture;
		});

		obj.scale.x=chessScale;
		obj.scale.y=chessScale;
		obj.scale.z=chessScale;
		arrayModel.push(obj);
		scene.add(obj);
	});
}

function loadPawn(src,row,col,func){
	loader.load("obj/"+src+".obj",function(obj){
		var kk=0.38;
		obj.position.y+=0.19;
		obj.position.x=(-3.5+col)*kk;
		obj.position.z=0.1+(-3.5+row)*kk;
		obj.scale.x=chessScale;
		obj.scale.y=chessScale;
		obj.scale.z=chessScale;
		arrayModel[arrayModel.length]=new Object();
		arrayModel[arrayModel.length]=obj;
		//arrayModel[arrayModel.length].row=row;
		//arrayModel[arrayModel.length].col=col;
		scene.add(obj);
	});
}

var qaq=0;
function tao(){
	qaq++;
	if(qaq!=32)return;
	for(var i=0;i<arrayBoard.length;i++){
		if(arrayBoard[i]==0)continue;
		//var mesh=new THREE.Mesh(arrayModel[arrayBoard[i]],new THREE.MeshLambertMaterial( { color: Math.random() * 0xff0000 } ) );
		//var mesh=new THREE.Mesh(geometry,new THREE.MeshLambertMaterial( { color: Math.random() * 0xffffff } ) );
		var mesh=arrayModel[arrayBoard[i]];
		if(mesh==null)
			console.log("null"+arrayBoard[i]);
		mesh.position.x=i%8*0.3;
		mesh.position.z=i/8*0.3;
		scene.add(mesh);
	}
}

function initPawns(){
	for(var i=0;i<arrayBoard.length;i++){
		var src;
		switch(arrayBoard[i]){
			case 0:
			continue;
			case 1:
			src="king_01";
			break;
			case 2:
			src="queen_01";
			break;
			case 3:
			src="bishop_01";
			break;
			case 4:
			src="knight_01";
			break;
			case 5:
			src="rook_01";
			break;
			case 6:
			src="pawn_01";
			break;
			case 7:
			src="king_02";
			break;
			case 8:
			src="queen_02";
			break;
			case 9:
			src="bishop_02";
			break;
			case 10:
			src="knight_02";
			break;
			case 11:
			src="rook_02";
			break;
			case 12:
			src="pawn_02";
			break;
		}
		loadPawn(src,parseInt(i/8),i%8,function(){tao();});
	}
	
	
	
	/*
	loadPawn("king_01",1,function(){tao();});
	loadPawn("queen_01",2,function(){tao();});
	loadPawn("bishop_01",3,function(){tao();});
	loadPawn("knight_01",4,function(){tao();});
	loadPawn("rook_01",5,function(){tao();});
	loadPawn("pawn_01",6,function(){tao();});
	loadPawn("king_02",7,function(){tao();});
	loadPawn("queen_02",8,function(){tao();});
	loadPawn("bishop_02",9,function(){tao();});
	loadPawn("knight_02",10,function(){tao();});
	loadPawn("rook_02",11,function(){tao();});
	loadPawn("pawn_02",12,function(){tao();});*/
}

var material=new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
function initChessBoard(s){
	scene=s;
	loadChessboard();
	initPawns();
}